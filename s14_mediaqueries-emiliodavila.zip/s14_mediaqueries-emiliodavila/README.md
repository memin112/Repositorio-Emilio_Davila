# S14_MediaQueries-EmilioDavila

A Pen created on CodePen.

Original URL: [https://codepen.io/memin112/pen/jEWmoEe](https://codepen.io/memin112/pen/jEWmoEe).

